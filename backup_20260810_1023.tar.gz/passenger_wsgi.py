import sys
import os
import pymysql

pymysql.install_as_MySQLdb()

sys.path.insert(0, '/home/cp65771/sanatpoya')
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'sanatpoya.settings')

from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()